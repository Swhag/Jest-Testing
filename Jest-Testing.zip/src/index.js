// import * as caesarCipher from './modules/caesarCipher';

// console.log(caesarCipher.isLowerCase('A'));
// console.log(caesarCipher.singleLowerCipher('a'));
// console.log(caesarCipher.caesarCipher('testing the water', 1));

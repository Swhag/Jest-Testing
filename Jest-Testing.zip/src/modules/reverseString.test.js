import reverseString from './reverseString';

test('returns reversed string', () => {
  expect(reverseString('hello')).toBe('olleh');
});
